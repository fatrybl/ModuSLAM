from main_manager.main_manager import MainManager

"""
Author: Mark Griguletskii.

Main runner of SLAM system.
"""


def run():
    main_manager = MainManager()
    main_manager.build_map()


if __name__ == "__main__":
    run()
