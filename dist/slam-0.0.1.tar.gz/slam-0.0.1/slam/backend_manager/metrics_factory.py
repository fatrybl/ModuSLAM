class MetricsFactory:
    def __init__(self):
        pass