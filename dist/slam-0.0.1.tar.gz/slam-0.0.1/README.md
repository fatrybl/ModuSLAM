# mySLAM

This is my own version of Factor Graph-based localization and mapping system
![alt text](/docs/diagrams/Pipeline/pipeline.png?raw=true "Pipeline Scheme")

Main roles of managers
![alt text](/docs/diagrams/Pipeline/managers.png?raw=true "Managers")
